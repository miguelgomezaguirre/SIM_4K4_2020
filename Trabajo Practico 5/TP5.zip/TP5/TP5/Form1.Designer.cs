﻿namespace TP5
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.iniciarSimulacion = new System.Windows.Forms.Button();
            this.grdResultado = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabParametros = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtPedidoGratisSegundos = new System.Windows.Forms.TextBox();
            this.txtAbandonoSegundos = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.txtPedidoGratisMinutos = new System.Windows.Forms.TextBox();
            this.txtPedidosPorHora = new System.Windows.Forms.TextBox();
            this.txtAbandonoMinutos = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txtPedidoGratisHoras = new System.Windows.Forms.TextBox();
            this.txtDemoraPedidosMedia = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtAbandonoHoras = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtTurnoSegundos = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTurnoMinutos = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtTurnoHoras = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btnValoresPorDefecto = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMediaDemora = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtPedidosPorViaje = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDesviacionSandwich = new System.Windows.Forms.TextBox();
            this.txtBPizzas = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDemoraHambLomito = new System.Windows.Forms.TextBox();
            this.txtMediaSandwich = new System.Windows.Forms.TextBox();
            this.txtAPizzas = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMediaEmpanadas = new System.Windows.Forms.TextBox();
            this.tabSimulacionTurno = new System.Windows.Forms.TabPage();
            this.tabSimulacionDiaria = new System.Windows.Forms.TabPage();
            this.grdResultados = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.lstPedidosPorHora = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCantidadEmpanadas = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCantidadLomitos = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCantidadHamburguesas = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblCantidadSandwich = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblCantidadPizzas = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblIngresoHamburguesas = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblIngresoLomito = new System.Windows.Forms.Label();
            this.lstRankingCocineros = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnSimularDia = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdResultado)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabParametros.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabSimulacionTurno.SuspendLayout();
            this.tabSimulacionDiaria.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdResultados)).BeginInit();
            this.SuspendLayout();
            // 
            // iniciarSimulacion
            // 
            this.iniciarSimulacion.Location = new System.Drawing.Point(12, 12);
            this.iniciarSimulacion.Name = "iniciarSimulacion";
            this.iniciarSimulacion.Size = new System.Drawing.Size(107, 23);
            this.iniciarSimulacion.TabIndex = 0;
            this.iniciarSimulacion.Text = "Iniciar Simulacion";
            this.iniciarSimulacion.UseVisualStyleBackColor = true;
            this.iniciarSimulacion.Click += new System.EventHandler(this.btnIniciarSimulacion_Click);
            // 
            // grdResultado
            // 
            this.grdResultado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdResultado.Location = new System.Drawing.Point(6, 6);
            this.grdResultado.Name = "grdResultado";
            this.grdResultado.Size = new System.Drawing.Size(954, 470);
            this.grdResultado.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabParametros);
            this.tabControl1.Controls.Add(this.tabSimulacionTurno);
            this.tabControl1.Controls.Add(this.tabSimulacionDiaria);
            this.tabControl1.Location = new System.Drawing.Point(12, 41);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(974, 508);
            this.tabControl1.TabIndex = 2;
            // 
            // tabParametros
            // 
            this.tabParametros.Controls.Add(this.groupBox4);
            this.tabParametros.Controls.Add(this.groupBox3);
            this.tabParametros.Controls.Add(this.btnValoresPorDefecto);
            this.tabParametros.Controls.Add(this.groupBox2);
            this.tabParametros.Controls.Add(this.groupBox1);
            this.tabParametros.Location = new System.Drawing.Point(4, 22);
            this.tabParametros.Name = "tabParametros";
            this.tabParametros.Size = new System.Drawing.Size(966, 482);
            this.tabParametros.TabIndex = 2;
            this.tabParametros.Text = "Parametros";
            this.tabParametros.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtPedidoGratisSegundos);
            this.groupBox4.Controls.Add(this.txtAbandonoSegundos);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.label30);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.txtPedidoGratisMinutos);
            this.groupBox4.Controls.Add(this.txtPedidosPorHora);
            this.groupBox4.Controls.Add(this.txtAbandonoMinutos);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.txtPedidoGratisHoras);
            this.groupBox4.Controls.Add(this.txtDemoraPedidosMedia);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.txtAbandonoHoras);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(423, 15);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(344, 189);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Simulacion";
            // 
            // txtPedidoGratisSegundos
            // 
            this.txtPedidoGratisSegundos.Location = new System.Drawing.Point(225, 155);
            this.txtPedidoGratisSegundos.Name = "txtPedidoGratisSegundos";
            this.txtPedidoGratisSegundos.Size = new System.Drawing.Size(46, 20);
            this.txtPedidoGratisSegundos.TabIndex = 6;
            this.txtPedidoGratisSegundos.Text = "0";
            // 
            // txtAbandonoSegundos
            // 
            this.txtAbandonoSegundos.Location = new System.Drawing.Point(58, 155);
            this.txtAbandonoSegundos.Name = "txtAbandonoSegundos";
            this.txtAbandonoSegundos.Size = new System.Drawing.Size(46, 20);
            this.txtAbandonoSegundos.TabIndex = 6;
            this.txtAbandonoSegundos.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(173, 79);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(160, 16);
            this.label36.TabIndex = 10;
            this.label36.Text = "Tiempo Pedido Gratis";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(176, 158);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 13);
            this.label35.TabIndex = 0;
            this.label35.Text = "ss";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 79);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(136, 16);
            this.label30.TabIndex = 10;
            this.label30.Text = "Tiempo Abandono";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 158);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(17, 13);
            this.label32.TabIndex = 0;
            this.label32.Text = "ss";
            // 
            // txtPedidoGratisMinutos
            // 
            this.txtPedidoGratisMinutos.Location = new System.Drawing.Point(225, 129);
            this.txtPedidoGratisMinutos.Name = "txtPedidoGratisMinutos";
            this.txtPedidoGratisMinutos.Size = new System.Drawing.Size(46, 20);
            this.txtPedidoGratisMinutos.TabIndex = 6;
            this.txtPedidoGratisMinutos.Text = "25";
            // 
            // txtPedidosPorHora
            // 
            this.txtPedidosPorHora.Location = new System.Drawing.Point(134, 17);
            this.txtPedidosPorHora.Name = "txtPedidosPorHora";
            this.txtPedidosPorHora.Size = new System.Drawing.Size(60, 20);
            this.txtPedidosPorHora.TabIndex = 1;
            this.txtPedidosPorHora.Text = "5";
            // 
            // txtAbandonoMinutos
            // 
            this.txtAbandonoMinutos.Location = new System.Drawing.Point(58, 129);
            this.txtAbandonoMinutos.Name = "txtAbandonoMinutos";
            this.txtAbandonoMinutos.Size = new System.Drawing.Size(46, 20);
            this.txtAbandonoMinutos.TabIndex = 6;
            this.txtAbandonoMinutos.Text = "0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(176, 132);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(23, 13);
            this.label34.TabIndex = 0;
            this.label34.Text = "mm";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Pedidos por hora";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(9, 132);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(23, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "mm";
            // 
            // txtPedidoGratisHoras
            // 
            this.txtPedidoGratisHoras.Location = new System.Drawing.Point(225, 103);
            this.txtPedidoGratisHoras.Name = "txtPedidoGratisHoras";
            this.txtPedidoGratisHoras.Size = new System.Drawing.Size(46, 20);
            this.txtPedidoGratisHoras.TabIndex = 6;
            this.txtPedidoGratisHoras.Text = "0";
            // 
            // txtDemoraPedidosMedia
            // 
            this.txtDemoraPedidosMedia.Location = new System.Drawing.Point(134, 43);
            this.txtDemoraPedidosMedia.Name = "txtDemoraPedidosMedia";
            this.txtDemoraPedidosMedia.Size = new System.Drawing.Size(60, 20);
            this.txtDemoraPedidosMedia.TabIndex = 6;
            this.txtDemoraPedidosMedia.Text = "3";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(176, 106);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(23, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "HH";
            // 
            // txtAbandonoHoras
            // 
            this.txtAbandonoHoras.Location = new System.Drawing.Point(58, 103);
            this.txtAbandonoHoras.Name = "txtAbandonoHoras";
            this.txtAbandonoHoras.Size = new System.Drawing.Size(46, 20);
            this.txtAbandonoHoras.TabIndex = 6;
            this.txtAbandonoHoras.Text = "1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 106);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "HH";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 46);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(122, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Demora Pedidos - media";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtTurnoSegundos);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.txtTurnoMinutos);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.txtTurnoHoras);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Location = new System.Drawing.Point(247, 132);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(170, 166);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Turno";
            // 
            // txtTurnoSegundos
            // 
            this.txtTurnoSegundos.Location = new System.Drawing.Point(55, 76);
            this.txtTurnoSegundos.Name = "txtTurnoSegundos";
            this.txtTurnoSegundos.Size = new System.Drawing.Size(46, 20);
            this.txtTurnoSegundos.TabIndex = 6;
            this.txtTurnoSegundos.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(55, 79);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "ss";
            // 
            // txtTurnoMinutos
            // 
            this.txtTurnoMinutos.Location = new System.Drawing.Point(55, 50);
            this.txtTurnoMinutos.Name = "txtTurnoMinutos";
            this.txtTurnoMinutos.Size = new System.Drawing.Size(46, 20);
            this.txtTurnoMinutos.TabIndex = 6;
            this.txtTurnoMinutos.Text = "0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(55, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "mm";
            // 
            // txtTurnoHoras
            // 
            this.txtTurnoHoras.Location = new System.Drawing.Point(55, 24);
            this.txtTurnoHoras.Name = "txtTurnoHoras";
            this.txtTurnoHoras.Size = new System.Drawing.Size(46, 20);
            this.txtTurnoHoras.TabIndex = 6;
            this.txtTurnoHoras.Text = "6";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(55, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(23, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "HH";
            // 
            // btnValoresPorDefecto
            // 
            this.btnValoresPorDefecto.Location = new System.Drawing.Point(6, 339);
            this.btnValoresPorDefecto.Name = "btnValoresPorDefecto";
            this.btnValoresPorDefecto.Size = new System.Drawing.Size(116, 23);
            this.btnValoresPorDefecto.TabIndex = 11;
            this.btnValoresPorDefecto.Text = "Valores por Defecto";
            this.btnValoresPorDefecto.UseVisualStyleBackColor = true;
            this.btnValoresPorDefecto.Visible = false;
            this.btnValoresPorDefecto.Click += new System.EventHandler(this.btnValoresPorDefecto_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMediaDemora);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtPedidosPorViaje);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Location = new System.Drawing.Point(247, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(170, 113);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Delivery";
            // 
            // txtMediaDemora
            // 
            this.txtMediaDemora.Location = new System.Drawing.Point(113, 45);
            this.txtMediaDemora.Name = "txtMediaDemora";
            this.txtMediaDemora.Size = new System.Drawing.Size(46, 20);
            this.txtMediaDemora.TabIndex = 6;
            this.txtMediaDemora.Text = "3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(52, 81);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Exponencial";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 48);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 13);
            this.label18.TabIndex = 5;
            this.label18.Text = "media demora (1/m)";
            // 
            // txtPedidosPorViaje
            // 
            this.txtPedidosPorViaje.Location = new System.Drawing.Point(113, 19);
            this.txtPedidosPorViaje.Name = "txtPedidosPorViaje";
            this.txtPedidosPorViaje.Size = new System.Drawing.Size(46, 20);
            this.txtPedidosPorViaje.TabIndex = 6;
            this.txtPedidosPorViaje.Text = "3";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(88, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Pedidos por viaje";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtDesviacionSandwich);
            this.groupBox1.Controls.Add(this.txtBPizzas);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtDemoraHambLomito);
            this.groupBox1.Controls.Add(this.txtMediaSandwich);
            this.groupBox1.Controls.Add(this.txtAPizzas);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txtMediaEmpanadas);
            this.groupBox1.Location = new System.Drawing.Point(15, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 285);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Productos";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(16, 195);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 13);
            this.label22.TabIndex = 8;
            this.label22.Text = "Desviación";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(103, 104);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "b";
            // 
            // txtDesviacionSandwich
            // 
            this.txtDesviacionSandwich.Location = new System.Drawing.Point(82, 192);
            this.txtDesviacionSandwich.Name = "txtDesviacionSandwich";
            this.txtDesviacionSandwich.Size = new System.Drawing.Size(49, 20);
            this.txtDesviacionSandwich.TabIndex = 9;
            this.txtDesviacionSandwich.Text = "5";
            // 
            // txtBPizzas
            // 
            this.txtBPizzas.Location = new System.Drawing.Point(122, 101);
            this.txtBPizzas.Name = "txtBPizzas";
            this.txtBPizzas.Size = new System.Drawing.Size(49, 20);
            this.txtBPizzas.TabIndex = 9;
            this.txtBPizzas.Text = "18";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(16, 223);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(183, 16);
            this.label23.TabIndex = 7;
            this.label23.Text = "Hamburguesas y Lomitos";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(13, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(138, 16);
            this.label20.TabIndex = 7;
            this.label20.Text = "Sandwich (Normal)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(13, 79);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "Pizzas (Uniforme)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(161, 16);
            this.label13.TabIndex = 6;
            this.label13.Text = "Empanadas (Poisson)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 248);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(42, 13);
            this.label25.TabIndex = 4;
            this.label25.Text = "demora";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(16, 171);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Media";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 105);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "a";
            // 
            // txtDemoraHambLomito
            // 
            this.txtDemoraHambLomito.Location = new System.Drawing.Point(82, 245);
            this.txtDemoraHambLomito.Name = "txtDemoraHambLomito";
            this.txtDemoraHambLomito.Size = new System.Drawing.Size(49, 20);
            this.txtDemoraHambLomito.TabIndex = 5;
            this.txtDemoraHambLomito.Text = "8";
            // 
            // txtMediaSandwich
            // 
            this.txtMediaSandwich.Location = new System.Drawing.Point(82, 166);
            this.txtMediaSandwich.Name = "txtMediaSandwich";
            this.txtMediaSandwich.Size = new System.Drawing.Size(49, 20);
            this.txtMediaSandwich.TabIndex = 5;
            this.txtMediaSandwich.Text = "10";
            // 
            // txtAPizzas
            // 
            this.txtAPizzas.Location = new System.Drawing.Point(35, 101);
            this.txtAPizzas.Name = "txtAPizzas";
            this.txtAPizzas.Size = new System.Drawing.Size(49, 20);
            this.txtAPizzas.TabIndex = 5;
            this.txtAPizzas.Text = "15";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(119, 41);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 13);
            this.label24.TabIndex = 2;
            this.label24.Text = "(demanda)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Media";
            // 
            // txtMediaEmpanadas
            // 
            this.txtMediaEmpanadas.Location = new System.Drawing.Point(59, 38);
            this.txtMediaEmpanadas.Name = "txtMediaEmpanadas";
            this.txtMediaEmpanadas.Size = new System.Drawing.Size(49, 20);
            this.txtMediaEmpanadas.TabIndex = 3;
            this.txtMediaEmpanadas.Text = "3";
            // 
            // tabSimulacionTurno
            // 
            this.tabSimulacionTurno.Controls.Add(this.grdResultado);
            this.tabSimulacionTurno.Location = new System.Drawing.Point(4, 22);
            this.tabSimulacionTurno.Name = "tabSimulacionTurno";
            this.tabSimulacionTurno.Padding = new System.Windows.Forms.Padding(3);
            this.tabSimulacionTurno.Size = new System.Drawing.Size(966, 482);
            this.tabSimulacionTurno.TabIndex = 0;
            this.tabSimulacionTurno.Text = "Simulacion Turno";
            this.tabSimulacionTurno.UseVisualStyleBackColor = true;
            // 
            // tabSimulacionDiaria
            // 
            this.tabSimulacionDiaria.Controls.Add(this.grdResultados);
            this.tabSimulacionDiaria.Location = new System.Drawing.Point(4, 22);
            this.tabSimulacionDiaria.Name = "tabSimulacionDiaria";
            this.tabSimulacionDiaria.Padding = new System.Windows.Forms.Padding(3);
            this.tabSimulacionDiaria.Size = new System.Drawing.Size(966, 482);
            this.tabSimulacionDiaria.TabIndex = 1;
            this.tabSimulacionDiaria.Text = "Simulacion Diaria";
            this.tabSimulacionDiaria.UseVisualStyleBackColor = true;
            // 
            // grdResultados
            // 
            this.grdResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdResultados.Location = new System.Drawing.Point(3, 6);
            this.grdResultados.Name = "grdResultados";
            this.grdResultados.Size = new System.Drawing.Size(957, 470);
            this.grdResultados.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1008, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Estadisticas";
            // 
            // lstPedidosPorHora
            // 
            this.lstPedidosPorHora.FormattingEnabled = true;
            this.lstPedidosPorHora.Location = new System.Drawing.Point(1011, 57);
            this.lstPedidosPorHora.Name = "lstPedidosPorHora";
            this.lstPedidosPorHora.Size = new System.Drawing.Size(272, 121);
            this.lstPedidosPorHora.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1008, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Cantidad de empanadas";
            // 
            // lblCantidadEmpanadas
            // 
            this.lblCantidadEmpanadas.AutoSize = true;
            this.lblCantidadEmpanadas.Location = new System.Drawing.Point(1206, 202);
            this.lblCantidadEmpanadas.Name = "lblCantidadEmpanadas";
            this.lblCantidadEmpanadas.Size = new System.Drawing.Size(13, 13);
            this.lblCantidadEmpanadas.TabIndex = 6;
            this.lblCantidadEmpanadas.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1008, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Cantidad de Lomitos";
            // 
            // lblCantidadLomitos
            // 
            this.lblCantidadLomitos.AutoSize = true;
            this.lblCantidadLomitos.Location = new System.Drawing.Point(1206, 215);
            this.lblCantidadLomitos.Name = "lblCantidadLomitos";
            this.lblCantidadLomitos.Size = new System.Drawing.Size(13, 13);
            this.lblCantidadLomitos.TabIndex = 8;
            this.lblCantidadLomitos.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1008, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Cantidad de Hamburguesas";
            // 
            // lblCantidadHamburguesas
            // 
            this.lblCantidadHamburguesas.AutoSize = true;
            this.lblCantidadHamburguesas.Location = new System.Drawing.Point(1206, 228);
            this.lblCantidadHamburguesas.Name = "lblCantidadHamburguesas";
            this.lblCantidadHamburguesas.Size = new System.Drawing.Size(13, 13);
            this.lblCantidadHamburguesas.TabIndex = 8;
            this.lblCantidadHamburguesas.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1008, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Cantidad de Sandwich";
            // 
            // lblCantidadSandwich
            // 
            this.lblCantidadSandwich.AutoSize = true;
            this.lblCantidadSandwich.Location = new System.Drawing.Point(1206, 241);
            this.lblCantidadSandwich.Name = "lblCantidadSandwich";
            this.lblCantidadSandwich.Size = new System.Drawing.Size(13, 13);
            this.lblCantidadSandwich.TabIndex = 8;
            this.lblCantidadSandwich.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1008, 254);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Cantidad de Pizzas";
            // 
            // lblCantidadPizzas
            // 
            this.lblCantidadPizzas.AutoSize = true;
            this.lblCantidadPizzas.Location = new System.Drawing.Point(1206, 254);
            this.lblCantidadPizzas.Name = "lblCantidadPizzas";
            this.lblCantidadPizzas.Size = new System.Drawing.Size(13, 13);
            this.lblCantidadPizzas.TabIndex = 8;
            this.lblCantidadPizzas.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1008, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ingreso por Hamburguesas";
            // 
            // lblIngresoHamburguesas
            // 
            this.lblIngresoHamburguesas.AutoSize = true;
            this.lblIngresoHamburguesas.Location = new System.Drawing.Point(1206, 286);
            this.lblIngresoHamburguesas.Name = "lblIngresoHamburguesas";
            this.lblIngresoHamburguesas.Size = new System.Drawing.Size(13, 13);
            this.lblIngresoHamburguesas.TabIndex = 10;
            this.lblIngresoHamburguesas.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1008, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Ingreso por Lomitos";
            // 
            // lblIngresoLomito
            // 
            this.lblIngresoLomito.AutoSize = true;
            this.lblIngresoLomito.Location = new System.Drawing.Point(1206, 299);
            this.lblIngresoLomito.Name = "lblIngresoLomito";
            this.lblIngresoLomito.Size = new System.Drawing.Size(13, 13);
            this.lblIngresoLomito.TabIndex = 10;
            this.lblIngresoLomito.Text = "0";
            // 
            // lstRankingCocineros
            // 
            this.lstRankingCocineros.FormattingEnabled = true;
            this.lstRankingCocineros.Location = new System.Drawing.Point(1011, 340);
            this.lstRankingCocineros.Name = "lstRankingCocineros";
            this.lstRankingCocineros.Size = new System.Drawing.Size(272, 56);
            this.lstRankingCocineros.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1008, 324);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Ranking uso de cocineros";
            // 
            // btnSimularDia
            // 
            this.btnSimularDia.Location = new System.Drawing.Point(125, 12);
            this.btnSimularDia.Name = "btnSimularDia";
            this.btnSimularDia.Size = new System.Drawing.Size(123, 23);
            this.btnSimularDia.TabIndex = 13;
            this.btnSimularDia.Text = "Simular Dia";
            this.btnSimularDia.UseVisualStyleBackColor = true;
            this.btnSimularDia.Click += new System.EventHandler(this.btnSimularDia_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(1007, 410);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(102, 20);
            this.label37.TabIndex = 16;
            this.label37.Text = "Integrantes";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "62476 - Ardiles Hernan Ulises",
            "53756 - Brizuela Marcelo",
            "40684 - Fabro Juan Pablo",
            "65130 - Gomez Aguirre Miguel",
            "64813 - Vildoza Gianni Luca"});
            this.listBox1.Location = new System.Drawing.Point(1011, 433);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(164, 82);
            this.listBox1.TabIndex = 15;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 26);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(23, 13);
            this.label38.TabIndex = 0;
            this.label38.Text = "HH";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 52);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(23, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "mm";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 78);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(17, 13);
            this.label40.TabIndex = 0;
            this.label40.Text = "ss";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 561);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btnSimularDia);
            this.Controls.Add(this.lstRankingCocineros);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblIngresoLomito);
            this.Controls.Add(this.lblIngresoHamburguesas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCantidadPizzas);
            this.Controls.Add(this.lblCantidadSandwich);
            this.Controls.Add(this.lblCantidadHamburguesas);
            this.Controls.Add(this.lblCantidadLomitos);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblCantidadEmpanadas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstPedidosPorHora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.iniciarSimulacion);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.grdResultado)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabParametros.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabSimulacionTurno.ResumeLayout(false);
            this.tabSimulacionDiaria.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button iniciarSimulacion;
        private System.Windows.Forms.DataGridView grdResultado;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabSimulacionTurno;
        private System.Windows.Forms.TabPage tabSimulacionDiaria;
        private System.Windows.Forms.DataGridView grdResultados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstPedidosPorHora;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCantidadEmpanadas;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCantidadLomitos;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCantidadHamburguesas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblCantidadSandwich;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblCantidadPizzas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblIngresoHamburguesas;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblIngresoLomito;
        private System.Windows.Forms.ListBox lstRankingCocineros;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSimularDia;
        private System.Windows.Forms.TabPage tabParametros;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPedidosPorHora;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMediaEmpanadas;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAPizzas;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBPizzas;
        private System.Windows.Forms.TextBox txtDemoraPedidosMedia;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPedidosPorViaje;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtMediaDemora;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtDesviacionSandwich;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtMediaSandwich;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtDemoraHambLomito;
        private System.Windows.Forms.Button btnValoresPorDefecto;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtTurnoHoras;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtTurnoSegundos;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtTurnoMinutos;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtAbandonoSegundos;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtAbandonoMinutos;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtAbandonoHoras;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtPedidoGratisSegundos;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtPedidoGratisMinutos;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtPedidoGratisHoras;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
    }
}

